# 祝福漂流瓶網站

這是一個可以放到 GitHub Pages 的互動網站。使用者可以填寫一次祝福語／心得，送出後會顯示在「祝福漂流瓶」牆上。

## 重要說明

GitHub Pages 本身是靜態網站，不能直接儲存所有人的留言。所以這個版本使用 Firebase Firestore 作為資料庫。

## 檔案

- `index.html`：網站結構
- `style.css`：網站外觀
- `script.js`：送出與讀取祝福語的互動功能

## 設定步驟

### 1. 建立 GitHub repository

上傳這三個檔案：

- `index.html`
- `style.css`
- `script.js`

### 2. 開啟 GitHub Pages

到 repository 的 Settings → Pages，Source 選 `Deploy from a branch`，Branch 選 `main`，Folder 選 `/root`。

### 3. 建立 Firebase 專案

1. 到 Firebase Console 建立新專案
2. 建立 Firestore Database
3. 建立 Web App
4. 複製 Firebase config
5. 貼到 `script.js` 的 `firebaseConfig`

### 4. Firestore Rules 測試版

```js
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    match /blessings/{docId} {
      allow read: if true;
      allow create: if
        request.resource.data.name is string &&
        request.resource.data.message is string &&
        request.resource.data.name.size() > 0 &&
        request.resource.data.name.size() <= 20 &&
        request.resource.data.message.size() > 0 &&
        request.resource.data.message.size() <= 160;
      allow update, delete: if false;
    }
  }
}
```

## 限制

目前「只能填寫一次」是用瀏覽器 localStorage 判斷，即同一部裝置／同一瀏覽器只能送一次。如果使用者換手機、換瀏覽器、清除瀏覽器資料，就可以再次送出。若要真正限制每人一次，需要加入登入功能。
